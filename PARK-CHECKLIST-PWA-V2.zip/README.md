# Park Checklist PWA — Version 2

Cette version contient la liste complète créée dans la conversation et conserve la progression existante lors des mises à jour.

## Mettre à jour le site GitHub Pages
1. Décompresse ce ZIP.
2. Dans ton dépôt GitHub, remplace les anciens fichiers par ceux de ce ZIP :
   - index.html
   - app.js
   - sw.js
   - manifest.webmanifest
   - icon-192.png
   - icon-512.png
3. Attends environ 1 à 3 minutes le redéploiement GitHub Pages.
4. Ouvre l'application dans Chrome et actualise la page.
5. Si l'ancienne version reste affichée, ferme complètement l'application et relance-la.

La nouvelle version utilise une migration : elle reprend les anciennes cases cochées et ajoute les parcs/attractions manquants.
